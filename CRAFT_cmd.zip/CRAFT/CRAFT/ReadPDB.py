class ReadPDB:
    def __init__(self, rf):
        self.chain=[]           #Chain present in given pdb
        self.sel_chain=[]       #Selected chains by user
        self.chain_at={}        #Track no. of atoms present in each chain
        
        self.het= {}            #Track hets using chain as key 
        self.het_seq=[]         #Track hetro atom sequence in pdb file
        self.het_name={}        #Track hets name using het code as key 
        self.het_at={}          #Track no. of atoms present in hets of chains 
        self.sel_hets={}        #Selected hetro by user
        
        self.res=[]             #Three letter residue code
        self.chain_id=[]        #chain id of each atom present in pdb file
        self.resn=[]            #Residues number
        self.atom_type=[]       #Record atom position i.e. alpha,beta
        self.atom=[]            #Atom type i.e. C,N,O
        self.charge=[]          #Charge on each atom
        self.pts=[]             #3D coordinates of atoms
        
        self.anisou=False
        
        word=rf.read(6).strip()
        at_count=0
        while(word!= "HETNAM" and word!= "ATOM"): 
            line=rf.readline()
            word=rf.read(6).strip()
        if(word == "HETNAM"):                   #Search for HETNAM in given pdb
            while(word!= "FORMUL"):
                line=rf.readline()
                line=" ".join(line.split())
                line=line.split(" ")
                if(len(line[0])==3):
                    self.het_name[line[0]]=" ".join(line[1:])
                else:
                    if line[1] in self.het_name.keys():
                        self.het_name[line[1]]+=" ".join(line[2:])
                word=rf.read(6).strip()
            while(word!= "ATOM"):               #Search for chains present in given pdb
                word=rf.read(6).strip()
                if(word=='ATOM'):
                    rf.read(15)
                    self.chain.append(rf.read(1))
                    at_count+=1                 #at_count=variable to count atoms present in each chain or ligand 
                line=rf.readline()
        else:
            if(word=='ATOM'):
                rf.read(15)
                self.chain.append(rf.read(1))
                line=rf.readline()
                at_count+=1
        word=rf.read(6).strip()
        while(word!= "END"):
            if(word == "TER"):
                #self.chain_at[self.chain[len(self.chain)-1]]=int(rf.read(5).split()[0]) #Picking atom no. present in the pDB file
                self.chain_at[self.chain[len(self.chain)-1]]=at_count
                at_count=0
                line=rf.readline()
                word=rf.read(6).strip()
                if word == "END":
                    break
                if(word == "ATOM"):
                    rf.read(15)
                    self.chain.append(rf.read(1))
            if(word == "HETATM"):                   #Search for hets present in chains of given pdb
                #at_no=int(rf.read(5).split()[0])
                rf.read(11)
                word1=rf.read(3).strip()
                if(word1 == "HOH"):
                    break
                else:
                    rf.read(1)
                    word2=rf.read(1)
                    if word2 in self.het.keys():
                        if word1 in self.het[word2]:
                            at_count+=1
                            self.het_at[word2][lig_count]=[word1, at_count]
                            line=rf.readline()
                            word=rf.read(6).strip()
                            continue
                        else:
                            self.het[word2].append(word1)
                            at_count=0
                            lig_count+=1
                            self.het_at[word2].append([word1, at_count+1])
                    else:
                        self.het[word2]=[word1]
                        self.het_seq.append(word2)
                        self.het_at[word2]=[[]]
                        at_count=0
                        lig_count=0
                        self.het_at[word2][lig_count]=[word1, at_count+1]
            if(word=="ANISOU"):
                self.anisou=True
                line=rf.readline()
                word=rf.read(6).strip()
            else:
                at_count+=1
                line=rf.readline()
                word=rf.read(6).strip()
    
    '''Display the different entries present in given pdb'''
    def display_entries(self):              
        for chain in self.chain:
            print(" Chain : ",chain)
            if chain in self.het.keys():
                print("         having : ")
                for value in self.het[chain]:
                    print("                ",value, end="")
                    if value in self.het_name.keys():
                        print("      i.e. ",self.het_name[value])
                    else:
                        print()
            else:
                print()
    
    '''Ask user to make selection according to available entries in the pdb'''
    def selection(self):                     
        self.sel_chain=list(input("Please select chains in capital letters seprated by comma for pocket prediction : ").split(","))
        print("self.sel_chain : ",self.sel_chain)
        if all(x in self.chain for x in self.sel_chain):
            print()
            print("Make ligand selection for selected chain :: ")
            print("Please select hets in capital letters seprated by comma for pocket prediction : or avoid selection by entering \"NA\"  :: ")
            for key in self.sel_chain:
                print()
                sel_het=[]
                if key in self.het.keys():
                    print("Select hets for chain : ",key," : out of : ",self.het[key])
                    sel_het=list(input(" Please select  :: ").split(","))
                if all(x in self.het[key] for x in sel_het):
                    self.sel_hets[key]=sel_het
                else:
                    if sel_het[0] == "NA":
                        pass
                    else:
                        print("You have made wrong selection. Please make selection as per hets present in the chain")
                        quit()
        else:
            print("Please provides correct chain in capital letters present in the listed chains ")
            quit()
    
    '''Display the selected entries present in given pdb'''
    def display_selected(self):              
        for chain in self.sel_chain:
            print(" Chain : ",chain)
            if chain in self.sel_hets.keys():
                print("         having : ")
                for value in self.sel_hets[chain]:
                    print("                ",value, end="")
                print()
            else:
                print()
    
    '''Read atom position, residues, 3D coordinates and atom type for selected entries'''
    def read_coords(self,rf):               
        rf.seek(0)
        word=rf.read(6).strip()
        while(word!= "ATOM"): 
            line=rf.readline()
            word=rf.read(6).strip()    
        '''Reading of selected chains'''         
        for chain in self.chain:
            index=self.chain.index(chain)           #Index use to find the location of chain in the dictionary
            if chain in self.sel_chain:
                if index ==0:
                    at_no=1
                else:
                    index-=1
                    at_no=1
                    while index >= 0:
                        at_no+=self.chain_at[self.chain[index]]+1       #at_no variable find the atom no. using store data in self.chain_at,self.het_at
                        index-=1
                while word!="TER":
                    read_atno=int(rf.read(5).split()[0])
                    if (at_no == read_atno):                        #read_atno reads atom number from the pdb file
                        rf.read(1)
                        self.atom_type.append(rf.read(4).strip())
                        self.res.append(rf.read(4).strip())
                        rf.read(1)
                        self.chain_id.append(rf.read(1))
                        self.resn.append(rf.read(4).strip())
                        rf.read(4)#previously it was 3
                        self.pts.append([float(rf.read(8).split()[0]),float(rf.read(8).split()[0]),float(rf.read(8).split()[0])])
                        rf.read(22)
                        self.atom.append(rf.read(2).strip())
                        self.charge.append(rf.read(2).strip())
                        at_no+=1
                        line=rf.readline()
                        word=rf.read(6).strip()
                    else:
                        if self.anisou== True:
                            rf.readline()
                            word=rf.read(6).strip()
                        else:
                            print("Warning: atom number ",at_no," missing from the given pdb")
                            print(at_no,"  :  ",read_atno)
                            rf.close()
                            quit()
                line=rf.readline()
                word=rf.read(6).strip()
            else:
                count=0
                while(count<=self.chain_at[self.chain[index]]):
                    rf.readline()
                    count+=1
                word=rf.read(6).strip()
        
        '''Reading of selected ligands'''
        at_no=1
        for chain in self.chain:
            at_no+=self.chain_at[chain]+1
        for chain in self.het_seq:
            if chain in self.sel_hets.keys():
                lig_count=0
                for lig in self.het_at[chain]:
                    if lig[0] in self.sel_hets[chain]:
                        for x in range(self.het_at[chain][lig_count][1]):
                            read_atno=int(rf.read(5).strip())
                            if (at_no == read_atno):
                                rf.read(1)
                                self.atom_type.append(rf.read(4).strip())
                                rf.read(1)
                                self.res.append(rf.read(3).strip())
                                rf.read(1)
                                self.chain_id.append(rf.read(1))
                                rf.read(1)
                                self.resn.append(rf.read(4).strip())
                                rf.read(3)
                                a=[float(rf.read(8).split()[0]),float(rf.read(8).split()[0]),float(rf.read(8).split()[0])]
                                self.pts.append(a)
                                rf.read(22)
                                self.atom.append(rf.read(2).strip())
                                self.charge.append(rf.read(2).strip())
                                at_no+=1
                            else:
                                print("Warning: Hetatom number ",at_no," missing from the given pdb")
                                rf.close()
                                quit()
                            line=rf.readline()
                            rf.read(6)
                    else:
                        at_no+=self.het_at[chain][lig_count][1]
                        for x in range(self.het_at[chain][lig_count][1]):
                            rf.readline()
                            rf.read(6)
                    lig_count+=1
            else:
                lig_count=len(self.het_at[chain])
                for lig in range(lig_count):
                    at_no+=self.het_at[chain][lig][1]
                    for x in range(self.het_at[chain][lig][1]):
                        rf.readline()
                        rf.read(6)
        
        rf.close()
        self.resn = list(map(int, self.resn))
    
    def select_position(self): 
        i=0
        alt_position=[]
        while i<len(self.res):
            list=[]
            alt=[]
            if len(self.res[i])>3:
                list.append(self.resn[i])
                list.append(self.chain_id[i])
                list.append(self.res[i][1:4])
                
                while self.resn[i]==int(list[0]):
                    if len(self.res[i])>3:
                        if self.res[i][0] not in alt:
                            alt.append(self.res[i][0])
                    i+=1
                list.append(alt)
                alt_position.append(list)
            else:
                i+=1
        
        sel_position=[]
        print("Make a position selection for alternate postion of following residues: ")
        print("alter : ",alt_position)
        for x in alt_position:
            print(" Alternate position present for ",x, " having current occupancy ",1/len(x[3]))        
            sel_position.append(input(" Please select  :: "))
            
        i=0
        for x in alt_position:
            index=self.resn.index(x[0])
            while self.chain_id[index]!=x[1]:
                index=self.resn.index(x[0],index+1)

            while self.resn[index]==x[0]:
                if len(self.res[index])>3:
                    if self.res[index][0]!=sel_position[i]:
                        del self.res[index]
                        del self.resn[index]
                        del self.chain_id[index]
                        del self.atom_type[index]
                        del self.atom[index]
                        del self.charge[index]
                        del self.pts[index]
                    else:
                        self.res[index]=self.res[index][1:4]
                        index+=1
                else:
                    index+=1
            i+=1
        
        #self.chain_at=len(self.res)
        
        
    
        
        
        
        
        
        
        
        
        
               