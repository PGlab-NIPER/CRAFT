import time
import os

import ReadPDB as rP
import Base as b
import tetrahedral
import Properties as pp

cwd = os.getcwd()
PDB_dir = os.path.join(cwd, 'PDB')
fn = (input("Enter the file name with its extension ")).split(".")
if(fn[1] == "pdb"):
    try:
        rf = open(os.path.join(PDB_dir,fn[0]+".pdb"), "r")
    except IOError:
        print("File not Found ")
    else:
        rPDB=rP.ReadPDB(rf)
        print("The given protein contains : ")
        rPDB.display_entries()
        rPDB.selection()
        print()
        print("Selected entries are :: ")
        print()
        rPDB.display_selected()
        rPDB.read_coords(rf)
        rPDB.select_position()
        start1=time.time()
        B=b.Base(rPDB,cwd)
        tt=tetrahedral.tetrahedral(rPDB,B)
        start=time.time()
        tt.delimiter_tetrahedral(10)
        end=time.time()
        print("delimiter  : ",end-start)
        start=time.time()
        tt.susceptible_tetra(4,4)       #susceptible tetrahedral volume and radii 4,4
        end=time.time()
        print("susceptible  : ",end-start)
        start=time.time()
        tt.cavity_scan(rPDB,1.4)
        end=time.time()
        print("cavity  : ",end-start)
        end1=time.time()
        print("total time without properties: ",end1-start1)
        
        start=time.time()
        prop=pp.Properties(tt,rPDB,B,fn[0],1.4,cwd)
        end=time.time()
        print("Properties : ",end-start)
        
        end1=time.time()
        print("total time eith properties : ",end1-start1)
        
